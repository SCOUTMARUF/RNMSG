
import React from 'react';

const events = [
  {
    id: 1,
    title: "Annual Tree Plantation Drive",
    date: "September 5, 2024",
    time: "9:00 AM - 1:00 PM",
    location: "Natore Town Park",
    category: "Community Service",
    description: "Join us in making our community greener. We'll be planting over 100 saplings. Gloves and tools will be provided."
  },
  {
    id: 2,
    title: "Weekend Camping Trip",
    date: "September 20-22, 2024",
    time: "Starts 4:00 PM on Friday",
    location: "Lalpur Forest Reserve",
    category: "Camping",
    description: "A weekend of camping, hiking, and learning survival skills. Open to all Scout and Rover sections. Don't forget your sleeping bag!"
  },
  {
    id: 3,
    title: "First Aid & Emergency Response Workshop",
    date: "October 12, 2024",
    time: "10:00 AM - 4:00 PM",
    location: "RNMSG Scout Hall",
    category: "Training",
    description: "A certified instructor will teach essential first aid techniques. This is a crucial skill for every scout. Lunch will be provided."
  },
  {
    id: 4,
    title: "Scout's Own & Campfire",
    date: "October 26, 2024",
    time: "6:00 PM - 9:00 PM",
    location: "RNMSG Group Grounds",
    category: "Gathering",
    description: "An evening of reflection, songs, and skits around the campfire. A great opportunity for all sections to bond."
  },
];

const getCategoryColor = (category: string) => {
    switch (category) {
        case 'Community Service': return 'bg-scout-blue text-white';
        case 'Camping': return 'bg-scout-green text-white';
        case 'Training': return 'bg-scout-red text-white';
        case 'Gathering': return 'bg-scout-yellow text-gray-900';
        default: return 'bg-gray-500 text-white';
    }
}

const EventPage: React.FC = () => {
  return (
    <div className="bg-white min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-extrabold text-scout-green tracking-tight">Upcoming Events</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
            Mark your calendars! Here's what's happening next at RNMSG.
          </p>
        </div>

        <div className="space-y-12">
          {events.map((event) => (
            <div key={event.id} className="md:flex bg-gray-50 rounded-xl shadow-lg overflow-hidden transition-shadow duration-300 hover:shadow-2xl">
              <div className="md:w-1/3 p-6 flex flex-col justify-center items-center bg-gray-100">
                  <div className="text-5xl font-bold text-scout-green">{event.date.split(' ')[1].replace(',', '')}</div>
                  <div className="text-xl font-semibold text-gray-700">{event.date.split(' ')[0]}</div>
                  <div className="text-md text-gray-500">{event.date.split(' ')[2]}</div>
              </div>
              <div className="p-8 md:w-2/3">
                <span className={`inline-block px-3 py-1 text-sm font-semibold rounded-full mb-3 ${getCategoryColor(event.category)}`}>
                    {event.category}
                </span>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">{event.title}</h3>
                <div className="flex items-center text-gray-600 mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    <span>{event.time}</span>
                </div>
                 <div className="flex items-center text-gray-600 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                    <span>{event.location}</span>
                </div>
                <p className="text-gray-700 leading-relaxed">{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventPage;