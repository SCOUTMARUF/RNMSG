
import React, { useState, useEffect } from 'react';

const galleryImages = [
    { id: 21, alt: "A scout group hiking on a trail" },
    { id: 433, alt: "Scouts setting up a tent in a forest" },
    { id: 450, alt: "A campfire with scouts gathered around" },
    { id: 476, alt: "Close-up of a scout tying a knot" },
    { id: 577, alt: "A team of scouts navigating with a map" },
    { id: 659, alt: "View from a mountain peak during a scout camp" },
    { id: 835, alt: "Scouts participating in a community service project" },
    { id: 985, alt: "A scout leader teaching a skill to younger members" },
    { id: 1041, alt: "Scouts canoeing on a calm lake" },
    { id: 1056, alt: "An award ceremony for scouts" },
    { id: 1060, alt: "A group photo of the entire scout troop" },
    { id: 1074, alt: "Scouts learning first-aid techniques" },
];

const GalleryPage: React.FC = () => {
    const [selectedImg, setSelectedImg] = useState<string | null>(null);

    const Modal = ({ src, alt, onClose }: { src: string; alt: string; onClose: () => void }) => {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-80 flex justify-center items-center z-50" onClick={onClose}>
                <div className="relative p-4">
                    <button onClick={onClose} className="absolute -top-4 -right-4 text-white text-3xl font-bold">&times;</button>
                    <img src={src} alt={alt} className="max-h-[85vh] max-w-[90vw] rounded-lg" />
                </div>
            </div>
        );
    };

  return (
    <div className="bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-extrabold text-scout-green tracking-tight">Our Memorable Moments</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
            A glimpse into our adventures, activities, and the bonds we've built.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image) => {
            const imageUrl = `https://picsum.photos/id/${image.id}/500/500`;
            return (
              <div key={image.id} className="group relative overflow-hidden rounded-lg cursor-pointer" onClick={() => setSelectedImg(imageUrl)}>
                <img
                  src={imageUrl}
                  alt={image.alt}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500 ease-in-out"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity duration-300 flex items-center justify-center">
                  <p className="text-white text-center p-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">{image.alt}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {selectedImg && <Modal src={selectedImg} alt="Enlarged gallery view" onClose={() => setSelectedImg(null)} />}
    </div>
  );
};

export default GalleryPage;
