
import React from 'react';

interface RecruitmentCardProps {
  title: string;
  age: string;
  description: string;
  imageUrl: string;
  colorClass: string;
}

const RecruitmentCard: React.FC<RecruitmentCardProps> = ({ title, age, description, imageUrl, colorClass }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300 ease-in-out">
      <img className="w-full h-56 object-cover" src={imageUrl} alt={title} />
      <div className="p-6">
        <h3 className={`text-2xl font-bold mb-2 ${colorClass}`}>{title}</h3>
        <p className="text-gray-500 font-semibold mb-3">{age}</p>
        <p className="text-gray-700 leading-relaxed mb-6">{description}</p>
        <button className={`w-full py-3 px-6 rounded-lg text-white font-semibold transition-opacity duration-300 ${colorClass.replace('text-', 'bg-')} hover:opacity-90`}>
          Learn More & Apply
        </button>
      </div>
    </div>
  );
};

const JoinPage: React.FC = () => {
  return (
    <div className="bg-gray-50 min-h-screen py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-extrabold text-scout-green tracking-tight">Join Our Adventure</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
            Begin your journey in scouting. Find the right section for you and become a part of our family.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          <RecruitmentCard
            title="Cub Scout Section"
            age="Ages 6 to 10"
            description="Cubs learn about the world, teamwork, and basic scouting skills through fun games, stories, and activities. It's the perfect start to a lifelong adventure."
            imageUrl="https://picsum.photos/400/300?image=1018"
            colorClass="text-scout-yellow"
          />
          <RecruitmentCard
            title="Scout Section"
            age="Ages 11 to 17"
            description="Scouts take on more challenges, develop leadership skills, and explore the outdoors. They work in patrols to plan adventures and serve their community."
            imageUrl="https://picsum.photos/400/300?image=1043"
            colorClass="text-scout-green"
          />
          <RecruitmentCard
            title="Rover Scout Section"
            age="Ages 18 to 25"
            description="Rovers focus on service, high adventure, and personal development. They manage their own programs and contribute to scouting at all levels."
            imageUrl="https://picsum.photos/400/300?image=839"
            colorClass="text-scout-red"
          />
        </div>
      </div>
    </div>
  );
};

export default JoinPage;
