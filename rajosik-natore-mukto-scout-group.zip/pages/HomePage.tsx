
import React from 'react';
import { Link } from 'react-router-dom';
import SocialIcons from '../components/SocialIcons';

const HomePage: React.FC = () => {
  return (
    <div className="animate-fadeIn">
      {/* Hero Section */}
      <section className="relative bg-cover bg-center h-[60vh] md:h-[80vh]" style={{backgroundImage: "url('https://picsum.photos/1920/1080?image=1073')"}}>
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center items-center text-center text-white">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight mb-4 text-shadow-lg">Rajosik Natore Mukto Scout Group</h1>
          <p className="text-lg md:text-2xl max-w-3xl mb-8">Building Leaders, Serving Community, Exploring Adventure.</p>
          <Link to="/join" className="bg-scout-yellow text-gray-900 font-bold py-3 px-8 rounded-full text-lg hover:bg-yellow-300 transition-transform transform hover:scale-105 duration-300">
            Join The Adventure
          </Link>
        </div>
      </section>

      {/* History Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <h2 className="text-3xl font-bold text-scout-green mb-4">Our History & Mission</h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                The Rajosik Natore Mukto Scout Group (RNMSG) is a proud and dynamic scouting organization based in the Natore District of Bangladesh. Since our inception, we have been dedicated to the development of young people in achieving their full physical, intellectual, emotional, social, and spiritual potentials as individuals, as responsible citizens, and as members of their local, national, and international communities.
              </p>
              <p className="text-gray-600 leading-relaxed">
                Our mission is to contribute to the education of young people, through a value system based on the Scout Promise and Law, to help build a better world where people are self-fulfilled as individuals and play a constructive role in society. We foster a spirit of camaraderie, leadership, and service, preparing our members for the challenges of today and tomorrow.
              </p>
            </div>
            <div className="order-1 md:order-2">
                <img src="https://picsum.photos/600/400?image=431" alt="Scouts in a circle" className="rounded-lg shadow-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* What We Do Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-scout-green mb-12">Our Core Activities</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <ActivityCard icon="🏕️" title="Camping & Outdoors" description="Developing survival skills, appreciating nature, and building teamwork through exciting outdoor adventures." />
            <ActivityCard icon="🤝" title="Community Service" description="Making a positive impact in Natore through volunteering, clean-up drives, and social awareness campaigns." />
            <ActivityCard icon="🧭" title="Leadership Training" description="Empowering youth with essential leadership qualities, decision-making skills, and self-confidence." />
            <ActivityCard icon="🏅" title="Skill Development" description="Offering a wide range of proficiency badges and skills, from first-aid and navigation to digital literacy." />
          </div>
        </div>
      </section>
      
      {/* Social Connect Section */}
      <section className="py-20 bg-scout-green text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Stay Connected</h2>
          <p className="text-lg max-w-2xl mx-auto mb-8">Follow our journey, get the latest updates on our activities, and see our scouts in action on our social media channels.</p>
          <div className="flex justify-center">
            <SocialIcons />
          </div>
        </div>
      </section>
    </div>
  );
};


interface ActivityCardProps {
    icon: string;
    title: string;
    description: string;
}

const ActivityCard: React.FC<ActivityCardProps> = ({ icon, title, description }) => {
    return (
        <div className="bg-white p-8 rounded-lg shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300">
            <div className="text-5xl mb-4">{icon}</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
            <p className="text-gray-600">{description}</p>
        </div>
    );
};


export default HomePage;
