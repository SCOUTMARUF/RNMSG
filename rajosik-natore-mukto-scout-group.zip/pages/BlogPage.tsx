
import React from 'react';

const blogPosts = [
  {
    id: 1,
    title: "Annual Summer Camp Highlights",
    category: "Camping",
    date: "August 15, 2024",
    excerpt: "Our scouts had an unforgettable week of adventure, learning new skills, and making lifelong friends at our annual summer camp. Read all about it!",
    imageUrl: "https://picsum.photos/id/1060/600/400"
  },
  {
    id: 2,
    title: "Community Clean-Up Drive Success",
    category: "Community Service",
    date: "July 22, 2024",
    excerpt: "RNMSG scouts took to the streets of Natore for our bi-annual clean-up drive, making a significant impact on our local environment.",
    imageUrl: "https://picsum.photos/id/835/600/400"
  },
  {
    id: 3,
    title: "Welcoming New Cub Scouts to the Pack",
    category: "Recruitment",
    date: "July 5, 2024",
    excerpt: "We were thrilled to welcome a new batch of enthusiastic Cub Scouts. The investiture ceremony was a proud moment for all.",
    imageUrl: "https://picsum.photos/id/1018/600/400"
  },
   {
    id: 4,
    title: "Leadership Training Workshop for Rover Scouts",
    category: "Training",
    date: "June 18, 2024",
    excerpt: "Our Rover Scouts participated in an intensive leadership workshop, honing their skills to become the leaders of tomorrow.",
    imageUrl: "https://picsum.photos/id/839/600/400"
  },
  {
    id: 5,
    title: "Mastering Knots and Lashings",
    category: "Skills",
    date: "May 30, 2024",
    excerpt: "This month's skill session focused on essential pioneering skills. Our scouts are now pros at various knots and lashings!",
    imageUrl: "https://picsum.photos/id/476/600/400"
  },
  {
    id: 6,
    title: "Exploring the Great Outdoors: A Hiking Expedition",
    category: "Adventure",
    date: "April 25, 2024",
    excerpt: "The Scout Section embarked on a challenging but rewarding hiking expedition, putting their navigation and teamwork skills to the test.",
    imageUrl: "https://picsum.photos/id/21/600/400"
  }
];

const BlogPage: React.FC = () => {
  return (
    <div className="bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-extrabold text-scout-green tracking-tight">News & Updates</h1>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-600">
            Stay up to date with our latest activities, achievements, and stories from the field.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {blogPosts.map((post) => (
            <div key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col group">
              <div className="overflow-hidden">
                <img className="w-full h-56 object-cover transform group-hover:scale-110 transition-transform duration-500 ease-in-out" src={post.imageUrl} alt={post.title} />
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <p className="text-sm text-scout-red font-semibold uppercase">{post.category}</p>
                <h3 className="text-xl font-bold mt-2 text-gray-800 group-hover:text-scout-green transition-colors duration-300">{post.title}</h3>
                <p className="text-xs text-gray-500 mt-1 mb-3">{post.date}</p>
                <p className="text-gray-600 leading-relaxed flex-grow">{post.excerpt}</p>
                <a href="#/blog" className="mt-4 font-semibold text-scout-green self-start hover:underline">
                  Read More &rarr;
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default BlogPage;
