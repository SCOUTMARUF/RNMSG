
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { logoBase64 } from '../assets/logo';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const linkClasses = "px-4 py-2 text-sm font-medium text-gray-700 hover:text-scout-green transition-colors duration-300";
  const activeLinkClasses = "text-scout-green border-b-2 border-scout-green";

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <NavLink to="/" className="flex items-center space-x-3">
              <img className="h-14 w-14" src={logoBase64} alt="RNMSG Logo" />
              <span className="font-bold text-lg text-scout-green hidden sm:block">
                RNMSG
              </span>
            </NavLink>
          </div>
          <div className="hidden md:block">
            <nav className="flex items-baseline space-x-4">
              <NavLink to="/" className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}>
                Home
              </NavLink>
              <NavLink to="/join" className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}>
                Join Us
              </NavLink>
              <NavLink to="/blog" className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}>
                Blog
              </NavLink>
               <NavLink to="/events" className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}>
                Events
              </NavLink>
              <NavLink to="/gallery" className={({ isActive }) => isActive ? `${linkClasses} ${activeLinkClasses}` : linkClasses}>
                Gallery
              </NavLink>
            </nav>
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-scout-green hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-scout-green"
              aria-controls="mobile-menu"
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              {!isOpen ? (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              ) : (
                <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <NavLink to="/" onClick={() => setIsOpen(false)} className={({isActive}) => `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-scout-green text-white' : 'text-gray-700 hover:bg-gray-200'}`}>Home</NavLink>
            <NavLink to="/join" onClick={() => setIsOpen(false)} className={({isActive}) => `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-scout-green text-white' : 'text-gray-700 hover:bg-gray-200'}`}>Join Us</NavLink>
            <NavLink to="/blog" onClick={() => setIsOpen(false)} className={({isActive}) => `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-scout-green text-white' : 'text-gray-700 hover:bg-gray-200'}`}>Blog</NavLink>
            <NavLink to="/events" onClick={() => setIsOpen(false)} className={({isActive}) => `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-scout-green text-white' : 'text-gray-700 hover:bg-gray-200'}`}>Events</NavLink>
            <NavLink to="/gallery" onClick={() => setIsOpen(false)} className={({isActive}) => `block px-3 py-2 rounded-md text-base font-medium ${isActive ? 'bg-scout-green text-white' : 'text-gray-700 hover:bg-gray-200'}`}>Gallery</NavLink>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;