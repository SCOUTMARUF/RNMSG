
import React from 'react';
import { logoBase64 } from '../assets/logo';
import SocialIcons from './SocialIcons';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div className="flex flex-col items-center md:items-start">
            <div className="flex items-center space-x-3 mb-4">
              <img className="h-12 w-12 bg-white rounded-full p-1" src={logoBase64} alt="RNMSG Logo" />
              <span className="font-bold text-xl">RNMSG</span>
            </div>
            <p className="text-gray-400">Rajosik Natore Mukto Scout Group</p>
            <p className="text-gray-400">Natore, 6400</p>
            <p className="text-gray-400">Bangladesh</p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold uppercase tracking-wider mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#/" className="hover:text-scout-yellow transition-colors">Home</a></li>
              <li><a href="#/join" className="hover:text-scout-yellow transition-colors">Join Us</a></li>
              <li><a href="#/blog" className="hover:text-scout-yellow transition-colors">Blog</a></li>
              <li><a href="#/events" className="hover:text-scout-yellow transition-colors">Events</a></li>
              <li><a href="#/gallery" className="hover:text-scout-yellow transition-colors">Gallery</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold uppercase tracking-wider mb-4">Connect With Us</h3>
            <div className="flex justify-center md:justify-start">
                <SocialIcons />
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-700 pt-8 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} Rajosik Natore Mukto Scout Group. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;